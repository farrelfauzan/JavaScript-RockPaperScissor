# Challenge Chapter 4

[Dokumentasi challenge chapter 4](https://docs.google.com/presentation/d/1x4oXTKeCQ8JbgvSP98Qd9CwfOGV4Birt/edit#slide=id.p1)

1. Kalian dipersilahkan untuk menambahkan file dan folder apapun di branch masing-masing.
2. Deadline challenge chapter 4 adalah Hari Senin 14 Februari 2022, pukul 23.59
